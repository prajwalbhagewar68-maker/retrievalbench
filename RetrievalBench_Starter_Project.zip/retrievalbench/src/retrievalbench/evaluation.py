from __future__ import annotations

from collections.abc import Mapping, Sequence


def recall_at_k(retrieved_ids: Sequence[str], relevant_ids: set[str], k: int = 5) -> float:
    if k <= 0:
        raise ValueError("k must be greater than zero")
    if not relevant_ids:
        return 0.0
    return len(set(retrieved_ids[:k]) & relevant_ids) / len(relevant_ids)


def precision_at_k(retrieved_ids: Sequence[str], relevant_ids: set[str], k: int = 5) -> float:
    if k <= 0:
        raise ValueError("k must be greater than zero")
    return len(set(retrieved_ids[:k]) & relevant_ids) / k


def reciprocal_rank(retrieved_ids: Sequence[str], relevant_ids: set[str]) -> float:
    for rank, doc_id in enumerate(retrieved_ids, start=1):
        if doc_id in relevant_ids:
            return 1.0 / rank
    return 0.0


def evaluate_query(
    retrieved: Sequence[Mapping],
    relevant_ids: set[str],
    k: int = 5,
) -> dict[str, float]:
    retrieved_ids = [str(item["doc_id"]) for item in retrieved]
    return {
        f"recall@{k}": recall_at_k(retrieved_ids, relevant_ids, k),
        f"precision@{k}": precision_at_k(retrieved_ids, relevant_ids, k),
        "mrr": reciprocal_rank(retrieved_ids, relevant_ids),
    }


def citation_validity(citations: Sequence[str], retrieved_chunk_ids: set[str]) -> dict[str, float | int]:
    """Check citation references against retrieved chunk IDs; this does not prove claim support."""
    if not citations:
        return {"valid_citations": 0, "total_citations": 0, "validity_rate": 0.0}
    valid = sum(citation in retrieved_chunk_ids for citation in citations)
    return {
        "valid_citations": valid,
        "total_citations": len(citations),
        "validity_rate": valid / len(citations),
    }
